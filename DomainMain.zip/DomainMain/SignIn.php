<?php
$conn=mysqli_connect("localhost","root","","domain");
session_start(); 

$Username1=($_POST['Username']);
$Password1=($_POST['Password']);
$SESSION['logged']=($_POST['Username']);

$result=mysqli_query($conn,"SELECT * FROM register WHERE Username='$Username1' and Password='$Password1'");

while(mysqli_fetch_array($result,MYSQLI_ASSOC)){
  
  header("location:IndexLogged.php");
}
if(!mysqli_fetch_array($result,MYSQLI_ASSOC)){
?>
<!DOCTYPE html>
         <html>
         <head>
         	<title>Failed</title>
         </head>
         <body style="background-color: grey;">
         	<center >
         		<div style="border-style: ridge;height: 40%;width: 40%;"><p style="color: mediumseagreen; font-size: 40px;">Invaild Entry..Login Again..</p>
         <a href="index.html" style="text-decoration: none;font-size: 30px;">Login from Home</a>
     </div></center>
         </body>
         </html>
         <?php
}
?>