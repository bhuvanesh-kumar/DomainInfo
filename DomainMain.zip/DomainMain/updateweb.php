<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "domain";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
 
$Img=addslashes(file_get_contents($_FILES['Img']['tmp_name']));
$sql = "INSERT INTO web (Data,Img)
VALUES ('".$_POST["Data"]."','{$Img}')";

if ($conn->query($sql) === TRUE) {
    ?>
    <!DOCTYPE html>
         <html>
         <head>
         	<title>Success</title>
         </head>
         <body style="background-color: grey;">
         	<center >
         		<div style="border-style: ridge;height: 40%;width: 40%;"><p style="color: mediumseagreen; font-size: 40px;">Information has been Updated</p>
         <a href="AdminLogged.html" style="text-decoration: none;font-size: 30px;">Back to Home</a>
     </div></center>
         </body>
         </html>
         <?php
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>