<?php
require 'master/PHPMailerAutoload.php'; 

           // $name=$_POST['name'];
          //  $mail=$_POST['email'];
            $mailto = $mail;
            $mailSub = "sample";
            $mailMsg = "hello this is the temporary mail .....".$name;
            $mail = new PHPMailer();
            $mail ->IsSmtp();
            $mail ->SMTPDebug = 0;
            $mail ->SMTPAuth = true;
            $mail ->SMTPSecure = 'ssl';
            $mail ->Host = "smtp.gmail.com";
            $mail ->Port = 465; // or 587
            $mail ->IsHTML(true);
            $mail ->Username = "rajeshwar18051999@gmail.com";
            $mail ->Password = "eternal1820";
            $mail ->SetFrom("rajeshwar18051999@gmail.com");
            $mail ->Subject = $mailSub;
            $mail ->Body = $mailMsg;
            $mail ->AddAddress($mailto);

            if($mail->Send())
             {
                 echo "<script>";
                 echo "alert('Mail Sent successfully....');";
                 echo "window.location.href='index.html';</script>";
             }
            else
             {
                  echo "<script>";
                 echo "alert('oops  Mail not Sent ');";
                 echo "window.location.href='index.html';</script>";              
             }
                    
       

     

?>


   

