<!DOCTYPE html>
<html lang="en" class="no-js">

<head>
	<meta charset="UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Domain-Info</title>
	<meta name="description" content="Blueprint: A basic template for a page stack navigation effect" />
	<meta name="keywords" content="blueprint, template, html, css, page stack, 3d, perspective, navigation, menu" />
	<meta name="author" content="Codrops" />
	<link rel="shortcut icon" href="favicon.ico">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/demo.css" />
	<link rel="stylesheet" type="text/css" href="css/component.css" />
	<link rel="stylesheet" type="text/css" href="signup.css">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<script src="js/modernizr-custom.js"></script>
	<style type="text/css">
		.but{
         	width: 100px;
         	height: 40px; 
         	font-size: 25px;
         	font-family: Lucida Console,Monaco,monospace;  
         	width:200px;  
         	background-color: #b4b4b4;
         	color:black;    	 
         }
        .tarea{
         	border-radius: 10px;
         	height: 40%;
         	width:50%;
         }
        .butt{
         	height: 40px; 
         	font-size: 25px;
         	font-family: Lucida Console,Monaco,monospace;  
            color:#7c7cd5;  
         } 
         table{
		height: 50%;
		width: 50%;
		margin-top: 10%;
		border-style: ridge;
		border-radius: 10px;
	}
		tr{
				font-size: 25px;
				text-align: center;
				color: pink;
				width: 50%;
				height:50%;
		}
	</style>
</head>

<body>
	<!-- navigation -->
	<nav class="pages-nav">
		<div class="pages-nav__item"><a class="link link--page" href="#page-home" style="font-size: 20px;color: pink">Home</a></div>
		<div class="pages-nav__item"><a class="link link--page" href="#page-docu" style="font-size: 20px;color: mediumseagreen">Domains</a></div>
		<div class="pages-nav__item"><a class="link link--page" href="#page-user" style="font-size: 20px;color: dodgerblue">View Users</a></div>
		<div class="pages-nav__item pages-nav__item--small"><a class="link link--page link--faded" style="font-size: 15px;color:#7c7cd5" href="#page-contact">Contact</a></div>
		<div class="pages-nav__item pages-nav__item--social">
			<a class="link link--social link--faded" href="#"><i class="fa fa-twitter"></i><span class="text-hidden">Twitter</span></a>
			<a class="link link--social link--faded" href="#"><i class="fa fa-linkedin"></i><span class="text-hidden">LinkedIn</span></a>
			<a class="link link--social link--faded" href="#"><i class="fa fa-facebook"></i><span class="text-hidden">Facebook</span></a>
			<a class="link link--social link--faded" href="#"><i class="fa fa-youtube-play"></i><span class="text-hidden">YouTube</span></a>
		</div>
	</nav>
	<!-- /navigation-->
	<!-- pages stack -->
	<div class="pages-stack">
		<!-- page -->
		<div class="page" id="page-home">
			    <form action="index.html">
					<span><button style="width:auto;float: right;margin-right: 10%;background-color: #7c7cd5;">LogOut</button></span>
			    </form>
			<!-- Blueprint header -->
			

			<header class="bp-header cf">
				
				
				<h1 class="bp-header__title"><span style="color: #7c7cd5;">D</span><span style="color: mediumseagreen;">o</span><span style="color: red;">m</span><span style="color: lightblue;">a</span><span style="color: white;">i</span><span style="color: pink;">n</span>-<span style="color: #7c7cd5;">I</span><span style="color: mediumseagreen;">n</span><span style="color: red;">f</span><span style="color: lightblue;">o</span></h1>
				<p class="bp-header__desc" style="font-size: 25px;">Get to know about the domains of your interest.</p>
				
                 <center>
<div class="w3-content w3-display-container">

<div class="w3-display-container mySlides">
  <img src="images/androidappdevelopment.jpg" style="width:100%;height: 600px;">
  <div class="w3-display-bottomleft w3-large w3-container w3-padding-16 w3-black" >
    Android App Development
  </div>
</div>

<div class="w3-display-container mySlides">
  <img src="images/bannerWebAppl.jpg" style="width:100%;height: 600px;">
  <div class="w3-display-bottomright w3-large w3-container w3-padding-16 w3-black">
    Web Technology
  </div>
</div>

<div class="w3-display-container mySlides">
  <img src="images/cloud.jpeg" style="width:100%;height: 600px;">
  <div class="w3-display-topleft w3-large w3-container w3-padding-16 w3-black">
    Cloud
  </div>
</div>

<div class="w3-display-container mySlides">
  <img src="images/datamining.png" style="width:100%;height: 600px;">
  <div class="w3-display-topright w3-large w3-container w3-padding-16 w3-black">
    DataMining
  </div>
</div>


<button class="w3-button w3-display-left w3-black" style="width: 5px;" onclick="plusDivs(-1)">&#10094;</button>
<button class="w3-button w3-display-right w3-black" style="width: 5px;" onclick="plusDivs(1)">&#10095;</button>

</div>

</center>

			</header>
		</div>

		<!-- page -->
		<div class="page" id="page-user">
			    <form action="index.html">
					<span><button style="width:auto;float: right;margin-right: 10%;background-color: #7c7cd5;">LogOut</button></span>
			    </form>

			<!-- Blueprint header -->
			

			<header class="bp-header cf">
              <center><span><h1 style="font-size: 50px;">Users</h1></span></center>
			</header>
             <center><table>
    <?php 
    $conn=mysqli_connect("localhost","root","","domain");
    $result=mysqli_query($conn,"SELECT Username,EmailID FROM register");
    while($row=mysqli_fetch_assoc($result))
{ 
  echo"<tr>";
  echo"<td>".$row['Username']. "</td>";

  echo"<td>".$row['EmailID']. "</td>";
 
  echo"</tr>";

}
?>
</table>
</center>
		</div>

		<!-- /page -->
		<div class="page" id="page-docu">
			<header class="bp-header cf">
				<h1 class="bp-header__title">Domains</h1>
				<p class="bp-header__desc">Choose the domain to get Knowledge</p>
				
			</header>
          
            <div><span><button onclick="document.getElementById('app').style.display='block'" style="width:auto;float: left;margin-left: 10%;background-color: #7c7cd5">App Development</button></span>
            <span><button onclick="document.getElementById('web').style.display='block'" style="width:auto;float: left;margin-left:10% ; background-color: mediumseagreen">Web Technology</button></span> 
            <span><button onclick="document.getElementById('cloud').style.display='block'" style="width:auto;float: right;margin-right: 10%; background-color: purple">Cloud Computing</button></span> 
            <span><button onclick="document.getElementById('mining').style.display='block'" style="width:auto;float: right;  margin-right:10% ;background-color: dodgerblue">Data Mining</button></span></div>
           
            <center><div><h1 style="color: dodgerblue;margin-top: 15%;">Be a better Info-Seeker with Domain-Info</h1></div></center>

           <!--App Development -->
			<div id="app" class="modal">
  <span onclick="document.getElementById('app').style.display='none'" class="close" title="Close Modal">&times;</span>
 <form method="POST" action="updateapp.php" enctype="multipart/form-data">
	<center><div><textarea class="tarea"  name="Data"></textarea>
	</div>
	<br>
	<div>
		<input  class="butt" type="file" name="Img" style="width: 40%;background-color: none;">
	</div>
	<br>
	<div>
         <input type="SUBMIT" class="but" name="SUBMIT">
         </div>
		</center>
	</form>
</div>
     
        <!--Web Technology -->
<div id="web" class="modal">
  <span onclick="document.getElementById('web').style.display='none'" class="close" title="Close Modal">&times;</span>
    <form method="POST" action="updateweb.php" enctype="multipart/form-data">
	<center><div><textarea class="tarea" name="Data"></textarea>
	</div>
	<br>
	<div>
		<input  class="butt" type="file" name="Img" style="width: 500px;background-color: none;">
	</div>
	<br>
	<div>
         <input type="SUBMIT" class="but" name="SUBMIT">
         </div>
		</center>
	</form>
   </div>
	</div>
</div>
	<!-- /pages-stack -->
	<button class="menu-button"><span>Menu</span></button>
	<script src="js/classie.js"></script>
	<script src="js/main.js"></script>


	<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}


var modal1 = document.getElementById('id02');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal1) {
        modal1.style.display = "none";
    }
}




var slideIndex = 1;
showDivs(slideIndex);
carousel();

function plusDivs(n) {
  showDivs(slideIndex += n);
}

function showDivs(n) {
  var i;
  var x = document.getElementsByClassName("mySlides");
  if (n > x.length) {slideIndex = 1}
  if (n < 1) {slideIndex = x.length}
  for (i = 0; i < x.length; i++) {
     x[i].style.display = "none";  
  }
  x[slideIndex-1].style.display = "block"; 
}
function carousel() {
  var i;
  var x = document.getElementsByClassName("mySlides");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none"; 
  }
  slideIndex++;
  if (slideIndex > x.length) {slideIndex = 1} 
  x[slideIndex-1].style.display = "block"; 
  setTimeout(carousel, 3000); 
}
</script>
</body>

</html>
