<?php
$conn=mysqli_connect("localhost","root","","domain");
// Check connection
if (!mysqli_connect_errno())
    {      
		    $username=$_POST['Username'];
                    $emailID=$_POST['EmailID'];
                    $password=$_POST['Password'];                 
                    $rePassword=$_POST['RePassword']; 
                    $_SESSION['email']=($_POST['EmailID']);                  

         mysqli_query($conn,"INSERT INTO register(Username,EmailID,Password,RePassword) 
         VALUES ('$username','$emailID','$password','$rePassword')"); 
         ?>
         <!DOCTYPE html>
         <html>
         <head>
         	<title>Success</title>
         </head>
         <body style="background-color: grey;">
         	<center >
         		<div style="border-style: ridge;height: 40%;width: 40%;"><p style="color: mediumseagreen; font-size: 40px;">Registered Successfully.Back to Home and Login to enter..</p>
         <a href="index.html" style="text-decoration: none;font-size: 30px;">Login from Home</a>
     </div></center>
         </body>
         </html>
        <?php
    }
   

    require 'master/PHPMailerAutoload.php'; 

            $mail=$_SESSION['email'];
            $mailto = $mail;
            $mailSub = "Registered Successfully";
            $mailMsg = "You have suucessfully registered into Domain-Info..";
            $mail = new PHPMailer();
            $mail ->IsSmtp();
            $mail ->SMTPDebug = 0;
            $mail ->SMTPAuth = true;
            $mail ->SMTPSecure = 'ssl';
            $mail ->Host = "smtp.gmail.com";
            $mail ->Port = 465; // or 587
            $mail ->IsHTML(true);
            $mail ->Username = "rajeshwar18051999@gmail.com";
            $mail ->Password = "eternal1820";
            $mail ->SetFrom("rajeshwar18051999@gmail.com");
            $mail ->Subject = $mailSub;
            $mail ->Body = $mailMsg;
            $mail ->AddAddress($mailto);

            if($mail->Send())
             {
                 echo "<script>";
                 echo "alert('Mail Sent successfully....');";
                 echo "window.location.href='index.html';</script>";
             }
            else
             {
                  echo "<script>";
                 echo "alert('oops  Mail not Sent ');";
                 echo "window.location.href='index.html';</script>";              
             }
                 
?>
