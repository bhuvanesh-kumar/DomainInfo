<?php
session_start();
date_default_timezone_set('Asia/Kolkata');
$con=mysqli_connect("localhost","root","","domain");
$date = date('Y-m-d H:i:s');
$name=$_POST['Userame'];
$type=$_POST['Message']; 
$a=mysqli_query($con,"INSERT INTO chat (Username,Message) 
         VALUES ('$name','$type')"); 
if($a)
{
		      header("location:IndexLogged.php");
		  }
		  else
		  {

		  	echo "insertion failed...";
                   }
?>
