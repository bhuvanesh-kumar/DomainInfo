<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "domain";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
 
$Img=addslashes(file_get_contents($_FILES['Img']['tmp_name']));
$sql = "INSERT INTO web (Data,Img)
VALUES ('".$_POST["Data"]."','{$Img}')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>