<?php
$conn=mysqli_connect("localhost","root","","domain");
// Check connection
if (!mysqli_connect_errno())
    {      
		    $username=$_POST['Username'];
                    $emailID=$_POST['EmailID'];
                    $password=$_POST['Password'];                 
                    $rePassword=$_POST['RePassword'];
                   

         mysqli_query($conn,"INSERT INTO register(Username,EmailID,Password,RePassword) 
         VALUES ('$username','$emailID','$password','$rePassword')"); 
		header("location:index.html");
    }
?>
