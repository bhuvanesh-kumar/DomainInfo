<?php
$conn=mysqli_connect("localhost","root","","domain");
session_start(); 

$Username1=($_POST['Username']);
$Password1=($_POST['Password']);

$result=mysqli_query($conn,"SELECT * FROM adminreg WHERE Username='$Username1' and Password='$Password1'");

while(mysqli_fetch_array($result,MYSQLI_ASSOC)){
  
 header("location:Admin.html");
}
if(!mysqli_fetch_array($result,MYSQLI_ASSOC)){
echo "Invalid Entry";
}
?>