<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		div{
			border-radius: 20px;
			background-color: #b4b4b4;
			padding: 50px;
			margin: 75px;
			margin-left: 270px;
			font-size: 20px;
			width: 50%;
			font-family: Lucida Console,Monaco,monospace;
			color: navy;
		}
			td{
				padding: 10px;
				padding-left: 40px;
				text-align: center;
			}

		.d{
			background-color: #b4b4b4;
			color: navy;
			padding: 5px;
			width: 55%;	
			margin-left: 270px;
			text-align: center;
			font-family:Lucida Console,Monaco,monospace;
		}
		.button {
    font-family: Lucida Console,Monaco,monospace;
    border: none;
    color: navy;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 21px;
    float:right;
    cursor: pointer;
}
.button:hover {
      background-color: white;
      color: navy;
 }
.button:active {
  background-color: black;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}
#chatimg{
        	height: 300px;
        	width: 300px;
        }		

	</style>
	
</head>
<body style="background-color:lightblue;">
	<span>
	<a href="Main.html" class="button"><b>Logout</b></a>
	<a href="MainLogged.html" class="button" style="float: left;"><b>Back</b></a><br>
</span>

	<div class="d">
		<h2>Web Technology Updates</h2>
	</div>
	<div id="chat"><center>
	<table>
     <?php 
		$conn=mysqli_connect("localhost","root","","domain");
		$result=mysqli_query($conn,"SELECT * FROM web");
		while($row=mysqli_fetch_assoc($result))
{
	echo"<tr>";
	echo"<td>".$row['data']. "</td>";
	echo"</tr>";	
	echo"<tr>";
	echo "<td>";
	echo'<img id="chatimg" src="data:image/jpeg;base64,'. base64_encode($row["img"]) .'"/>';
	echo "</td>";
	echo"</tr>";

}
?>
</table>
</center>
</div>
</body>
</html>